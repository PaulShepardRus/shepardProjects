﻿// Данная работа является курсовым проектом студента ГУАП Шепелева П.К. за 3 курс по курсу Инфокоммуникационные системы и сети,2018г.
// Тема: Реализация алгоритма "Несинхронная Аллоха".
// Курс проходил под руководством Тюрликова Андрея Михайловича.
//
//
//
//
//
//
//
//
//
//
//
//
//














using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kyrsovik_tyrlikov
{
    class Program
    {

        static Random rdn = new Random();
        static Random rdn_more_cap = new Random();
        static Random rand_messages = new Random();
        static double which_interval_mark;
        static int greatest;
        static decimal temp;
        static int kolvo;


        static decimal d_cap;
        static decimal zanyato_next_okno;
        static bool v_okne_otpravka_idet;


     //   static double intensivnost_vhodnogo_cap = 1.3;
      //  static int intensivnost_obrabotki = 1;

        static int kol_vo_abonentov = 1;
        static int vsego_otparvlyaem_soobjeniy = 1000000;
        static double p_toSend = 1;
        static float lambda_vhodnogo = 0.5f;
        static int cap_msg = vsego_otparvlyaem_soobjeniy / 1;


        // переменные, которые надо использовать вне их методов
        static int isSomeOneSending_counter = 0;
        static int whoSendingInThisWindow = -1;
        static int nomerOjid = -1;
        static int[] WhoWananSend;

        static Customer klient;
        static Customer klint;
        static Customer Klient;
        static int kolvo_novih;
        static int SummarnoVOcheredi;
        static int howMuchOfCustomersSendedAlready;
        static Customer[] ujeOtprKlt;
        static int howMuchHaveMSGToSend;
        static int sitRes;
        static int nomerOtprv;
        static double averageN;
        static double averageNTheor;

        //for logs - uncomment this to see log results
       // static StringBuilder sb = new StringBuilder();
       // static StreamWriter sw = new StreamWriter("C:\\Users\\fgfgfgfgfgfgfgfgfgfg\\Desktop\\Vyz\\labs 3 curse 1 semester\\Data protocols and stuff\\kyrsovik\\logsAssinh.txt");

        static Customer[] novOtprKlt;
        static void Main(string[] args)
        {
            int kolvo_opravlyaemih = 0;
            int real_time_spent_total = 0;
            decimal d = 0;
            decimal averageD = 0;
            decimal averageTheorD = 0;

            Random rand_time = new Random();
            decimal[] interval_vals = new decimal[12]; // 12 интервалов

            Customer customer1 = new Customer(vsego_otparvlyaem_soobjeniy, "Customer1");
            decimal zanyato_next_okno = 0;
            decimal d_min_old = 1;
            decimal d_max_new = 0;
            decimal d_min_new = 1;
            bool v_okne_otpravka_idet = false;

            decimal[] arr;

            // Курсовик
            // всего клиентов заполняю
            Customer[] customers = new Customer[kol_vo_abonentov];
            for (int i = 0; i < kol_vo_abonentov; i++)
            {
                string name = "Abonent" + i;
                customers[i] = new Customer(vsego_otparvlyaem_soobjeniy + 1000, name);
            }


            lambda_vhodnogo = lambda_vhodnogo / kol_vo_abonentov;
            CreateIntervals(interval_vals, lambda_vhodnogo);
            for (int dummy = 0; ; dummy++)
            {
                // -----------------------------------------------------------------------------------------------------------------------------------------
                // Каждый такой цикл- окно, в котором и приходят сообщения, кол-во которых определяется ниже
                if (getKolvoDostavlennih(customers) == cap_msg)
                {
                    break;
                }
                real_time_spent_total++;
             //   if (real_time_spent_total == 100) { sw.Write(sb); sw.Flush(); }
             //   sb.Append("\nТекущее окно : " + real_time_spent_total);
                for (int i = 0; i < kol_vo_abonentov; i++)
                {
                    klient = customers[i];
                    klient.timeMsgAll += klient.klvInBuf;
                }
                kolvo_novih = 0;
                for (int i = 0; i < kol_vo_abonentov; i++)
                {
                    klint = customers[i];
                    kolvo_opravlyaemih = HowMuchToSend(lambda_vhodnogo, interval_vals);
                    kolvo_novih += kolvo_opravlyaemih;
                    averageN += kolvo_opravlyaemih;
                    klint.dobVPoslOkne = kolvo_opravlyaemih;
                    //sb.Append("\n " + klint.name + " добавил 'текущем окне' : " + klint.dobVPoslOkne );
                    for (int w = 0; (w < kolvo_opravlyaemih); w++)
                    {
                        if (klint.nmrSledBuf == klint.klvMsgVsego) { break; }
                        klint.msgs[customers[i].nmrSledBuf, 1] = 1; // 1 означает ушло в собственную очередь  2 - в общую 3 - обработано
                        klint.nmrSledBuf++;
                        klint.klvInBuf++;
                    }
                }
                // ЭТА ЛОГИКА У КАЖДОГО ОКНА, В КАЖДОМ ОКНЕ - ещё внизу
                // -----------------------------------------------------------------------------------------------------------------------------------------
                SummarnoVOcheredi = getSummarnoVkajdoyOcheredi(customers); //approved
                if (v_okne_otpravka_idet == false && SummarnoVOcheredi == 0) { continue; }
                if (v_okne_otpravka_idet == false & SummarnoVOcheredi > 0) // пустая система
                {
                    d_min_old = 1;
                    d_max_new = 0;
                    howMuchHaveMSGToSend = getKolvoCustomerWhoWannaSend(customers);
                    novOtprKlt = HandleSituation(howMuchHaveMSGToSend, customers);
                    if (novOtprKlt.Length > 0)
                    {
                        for (int i = 0; i < novOtprKlt.Length; i++)
                        {
                            Klient = novOtprKlt[i];
                            nomerOjid = Klient.getNomerOjidaemogo();
                            if (Klient.msgs[nomerOjid, 1] != 1)
                            {
                                throw new System.ArgumentException("ОШИБКА! ПЫТАЕМСЯ ОТПРАВИТЬ СООБЩЕНИЕ, КОТОРОЕ ЕЩЁ НЕ В БУФЕРЕ У КЛИЕНТА");
                            }
                            Klient.msgs[nomerOjid, 1] = 2;
                            Klient.msgs[nomerOjid, 2] = 1;
                            Klient.msgs[nomerOjid, 0] = (decimal)rand_messages.NextDouble();
                            if (novOtprKlt.Length > 1) { Klient.msgs[nomerOjid, 3] = 1; } // испорчены оба
                            if (d_min_old >= Klient.msgs[nomerOjid, 0]) // наименьший d
                                d_min_old = Klient.msgs[nomerOjid, 0];
                            v_okne_otpravka_idet = true;
                         //   sb.Append("\nКлиент " + Klient.name + " отправил сообщение с номером " + nomerOjid);
                        }
                    }else
                    if (novOtprKlt.Length == 0) { continue; }
                }
                else // непустая система
                {
                    // делать тут чтобы новые становилиь из предыдущего
                    howMuchOfCustomersSendedAlready = getKolvoCustomersWhoAlreadySended(customers);
                    ujeOtprKlt = getIndexesOfCustomerWhoOtpravilSoobshenie(customers, howMuchOfCustomersSendedAlready);
                    for (int i = 0; i < ujeOtprKlt.Length; i++) {
                        ujeOtprKlt[i].msgs[ujeOtprKlt[i].getNomerOtpravlennogo(), 2] = 1;
                    }

                    howMuchHaveMSGToSend = getKolvoCustomerWhoWannaSend(customers);
                    novOtprKlt = HandleSituation(howMuchHaveMSGToSend, customers);
                    for (int i = 0; i < novOtprKlt.Length; i++)
                    {
                        Klient = novOtprKlt[i];
                        nomerOjid = Klient.getNomerOjidaemogo();

                        if (Klient.msgs[nomerOjid, 1] != 1) // должно быть, потому что предыдущую проверку прошёл
                        {
                            throw new System.ArgumentException("ОШИБКА! ПЫТАЕМСЯ ОТПРАВИТЬ СООБЩЕНИЕ, КОТОРОЕ ЕЩЁ НЕ В БУФЕРЕ У КЛИЕНТА");
                        }
                        Klient.msgs[nomerOjid, 1] = 2;
                        Klient.msgs[nomerOjid, 2] = 2;
                        if (novOtprKlt.Length > 1) { Klient.msgs[nomerOjid, 3] = 1; } // испорчены оба

                        Klient.msgs[nomerOjid, 0] = (decimal)rand_messages.NextDouble();
                        if (d_max_new <= Klient.msgs[nomerOjid, 0]) // наибольший d
                            d_max_new = Klient.msgs[nomerOjid, 0];
                        if (d_min_new >= Klient.msgs[nomerOjid, 0])
                            d_min_new = Klient.msgs[nomerOjid, 0];
                        zanyato_next_okno = 1 - d_max_new;
                        v_okne_otpravka_idet = true;
                   //     sb.Append("\nКлиент " + Klient.name + " отправил сообщение с номером " + nomerOjid);
                    }
                    if (novOtprKlt.Length == 0) { v_okne_otpravka_idet = true;}

                    // что делаем с предыдущими сообщениями в системе:  
                    if (ujeOtprKlt.Length > 0)  {
                        if (d_max_new >= d_min_old && isConflict() ) // наложиление сообщений друг на друга
                        { //испорчены сообщения
                           
                            for (int i = 0; i < ujeOtprKlt.Length; i++) {
                                Klient = ujeOtprKlt[i];
                                nomerOtprv = Klient.getNomerOtpravlennogo();
                                if (twoSended(Klient)) {
                                    if (!(Klient.msgs[nomerOtprv, 2] == 1)) {
                                        nomerOtprv = nomerOtprv + 1; // если сообщение пришло из предыдущего окна, то его [2] - едененица -работаем с ним
                                    }                                // если у него статус не еденица, а 2, то оно свежее, а надо работать со старым
                                }
                                if (nomerOtprv == -1) { throw new System.ArgumentException("ОШИБКА! ПЫТАЕМСЯ ОТПРАВИТЬ СООБЩЕНИЕ, КОТОРОЕ ЕЩЁ НЕ В КОНВЕЕРЕ"); }
                                Klient.msgs[nomerOtprv, 0] = 0; // время в системе становится 0
                                Klient.msgs[nomerOtprv, 1] = 1; // обратно в буфер
                                Klient.msgs[nomerOtprv, 3] = 0; // снимая марку о испорченности 
                                Klient.msgs[nomerOtprv, 2] = 0;
                              //  sb.Append("\nКлиент " + Klient.name + " - произошло наложение сообщения " + nomerOjid);
                            }
                            for (int i = 0; i < novOtprKlt.Length; i++) {
                                Klient = novOtprKlt[i];
                                nomerOtprv = Klient.getNomerOtpravlennogo();
                                if (nomerOtprv == -1) { nomerOtprv = Klient.getNomerOjidaemogo(); }
                                Klient.msgs[nomerOtprv, 3] = 1;
                                }
                        }
                        else
                        { // не испорчены сообщения, во всяком случае если до этого не испорчены
                            for (int i = 0; i < ujeOtprKlt.Length; i++)
                            {
                                Klient = ujeOtprKlt[i];
                                nomerOtprv = Klient.getNomerOtpravlennogo();
                                if (nomerOtprv == -1)
                                {
                                    throw new System.ArgumentException("ОШИБКА! ПЫТАЕМСЯ ОТПРАВИТЬ СООБЩЕНИЕ, КОТОРОЕ ЕЩЁ НЕ В КОНВЕЕРЕ");
                                }
                               
                                if (Klient.msgs[nomerOtprv, 3] != 1 && ujeOtprKlt.Length == 1 && Klient.nmrPoslUsp + 1 == nomerOtprv)
                                {
                                    Klient.msgs[nomerOtprv, 1] = 3;
                                    Klient.klvInBuf--;
                                    Klient.klvUspPer++;
                                    Klient.nmrPoslUsp = nomerOtprv;
                                  //  sb.Append("\n Клиент " + Klient.name + " успешно доставил сообщение " + nomerOjid);
                                }
                                else { Klient.msgs[nomerOtprv, 1] = 1; }
                                Klient.msgs[nomerOtprv, 0] = 0;
                                Klient.msgs[nomerOtprv, 3] = 0;
                                Klient.msgs[nomerOtprv, 2] = 0;
                            }
                        }
                        d_min_old = d_min_new;
                        d_max_new = 0;
                    }else
                    if (ujeOtprKlt.Length == 0) { continue;  }

                }
            }



            d = 0;
            for (int i = 0; i < customers.Length; i++)
                d += customers[i].timeMsgAll;
            int kol_vo_prinyatih = getKolvoDostavlennih(customers);
         //   averageD = d / kol_vo_prinyatih;
        //    averageTheorD = (decimal)(2 - lambda_vhodnogo) / (decimal)(2 * (1 - lambda_vhodnogo));
            float intensivnostVih = (float)kol_vo_prinyatih / real_time_spent_total;
            lambda_vhodnogo = lambda_vhodnogo * kol_vo_abonentov;
        }

        private static bool twoSended(Customer cus1)
        {
            if ((cus1.msgs[cus1.getNomerOtpravlennogo(), 1] == 2) & (cus1.msgs[cus1.getNomerOtpravlennogo() + 1, 1] == 2))
            {
                return true;
            }
            else return false;
        }

        private static bool isConflict()
        {
            bool res = false;
            Customer cus1;
            Customer cus2;
            for (int i = 0; i < ujeOtprKlt.Length; i++) {
                cus1 = ujeOtprKlt[i];
                for (int q = 0; q < novOtprKlt.Length; q++) {
                    cus2 = novOtprKlt[q];
                    if (cus1.name == cus2.name)
                    {
                        // один и тот же отправитель - нет конфликта
                        res = false;
                        continue;
                    }
                    else {
                        if (cus1.msgs[cus1.getNomerOtpravlennogo(), 0] < cus2.msgs[cus2.getNomerOtpravlennogo(), 0]) {
                            res = true;
                            return res;
                            
                        }

                    }

                }
            }
            return res;            
        }

        public static int howMuchSending(Customer[] customers)
        {
            int kolvo = 0;
            for (int i = 0; i < customers.Length; i++)
            {
                if (customers[i].getIfSender()) { kolvo++; }
            }
            return kolvo;
        }

        static int HowMuchToSend(float lambda, decimal[] intervals)
        {
            kolvo = 0;
            which_interval_mark = rdn.NextDouble();
            for (int i = 0; i < intervals.Length - 1; i++)
            { 
                if (Module(intervals[i + 1] - intervals[i]) == 0)
                {
                  
                    kolvo = i;
                    break;
                }
                else
                {
                    if (Module(intervals[i + 1] - intervals[i]) > (Module(intervals[i + 1] - (decimal)which_interval_mark)) &
                    Module(intervals[i + 1] - intervals[i]) > (Module(intervals[i] - (decimal)which_interval_mark)))
                    {
                        kolvo = i;
                        break;
                    }
                }
            }
            return kolvo;
        }
        static void CreateIntervals(decimal[] intervals, double lambda)
        {
            intervals[0] = 0;
            int kFactorial = 0;
            decimal numerator = 0;
            decimal p = 0;
            for (int k = 1; k < intervals.Length; k++)
            {
                kFactorial = Factorial(k - 1);
                numerator = (decimal)Math.Pow(Math.E, -(double)lambda) *
                    (decimal)Math.Pow((double)lambda, (double)k - 1);
                p = (decimal)numerator / kFactorial;
                if (p + intervals[k - 1] > 1)
                {
                    intervals[k] = 1;
                }
                else
                    intervals[k] = p + intervals[k - 1];
            }
        }
        //averageN = averageN / real_time_spent_total;
       // averageNTheor = (lambda_vhodnogo* (2 - lambda_vhodnogo)) / (2 * (1 - lambda_vhodnogo));
         //   averageTheorD = (decimal)(2 - lambda_vhodnogo) / (decimal)(2 * (1 - lambda_vhodnogo));
        static private int Factorial(int k)
        {
            int count = k;
            int factorial = 1;
            while (count >= 1)
            {
                factorial = factorial * count;
                count--;
            }
            return factorial;
        }
        static decimal Module(decimal val)
        {
            val = (val > 0) ? val : -val;
            return val;
        }
        static void sortUptoDown(decimal[] arrToSort)
        { 
            greatest = -1;
            temp = 0;
            for (int i = 0; i < arrToSort.Length; i++)
                for (int k = arrToSort.Length - 1; k > i; k--)
                {
                    if (arrToSort[k] > arrToSort[k - 1])
                    {
                        temp = arrToSort[k - 1];
                        arrToSort[k - 1] = arrToSort[k];
                        arrToSort[k] = temp;
                    }
                }
        }


        static int getSummarnoVkajdoyOcheredi(Customer[] customers)
        {
            int skolko_peredayt = 0;
            for (int i = 0; i < customers.Length; i++)
            {
                skolko_peredayt += customers[i].getKolvoOtpravlennih();
            }
            return skolko_peredayt;
        }
        public static int getKolvoCustomerWhoWannaSend(Customer[] customers)
        {
            int kolvo = 0;
            for (int i = 0; i < customers.Length; i++)
            {
                if (customers[i].getKolvoOtpravlennih() > 0) {kolvo++;}
            }
            return kolvo;
        }
        
        public static Customer[] HandleSituation(int HowMuchWannaSend, Customer[] customers)
        {
            Customer[] arr = new Customer[0];
            isSomeOneSending_counter = 0;
            if (HowMuchWannaSend == 0) { return arr; } 
            WhoWananSend = new int[customers.Length];
            for (int i = 0; i < customers.Length; i++)
            {
                if (rand_messages.NextDouble() < p_toSend && customers[i].getKolvoOtpravlennih() != 0) 
                {                                   
                    WhoWananSend[i] = 1;
                  //  sb.Append("\n Клиент " + customers[i].name + " решил отправить сообщение" );
                    isSomeOneSending_counter++; 
                }
                else {
                   
                    WhoWananSend[i] = 0; }
            }
            arr = new Customer[isSomeOneSending_counter];
            int help_var = 0;
            for (int i = 0; i < WhoWananSend.Length; i++) {
                if (WhoWananSend[i] == 1) {
                    arr[help_var] = customers[i];
                    help_var++;
                }
            }
            return arr; 
        }

        public static int getKolvoCustomersWhoAlreadySended(Customer[] customers)
        {
            int kolvo = 0;
            for (int i = 0; i < customers.Length; i++)
            {
                if (customers[i].getIfSender()) {
                    kolvo++;
                }
            }
            return kolvo;
        }
        static public int getKolvoDostavlennih(Customer[] customers)
        {
            int res = 0;
            for (int i = 0; i < customers.Length; i++)
            {
                res += customers[i].getKolvoYjePrinyatih();
            }
            return res;
        }
        public static Customer[] getIndexesOfCustomerWhoOtpravilSoobshenie(Customer[] customers, int kolvoOtpraviteley)
        {
            Customer[] arr = new Customer[kolvoOtpraviteley];
            int help_var = 0;
            for (int i = 0; i < customers.Length; i++){
                if (customers[i].getIfSender()){
                    arr[help_var] = customers[i];
                    help_var++;
                }
            }
            return arr;
        }
    }

    public class Customer
    {
        public string name;
        public int klvMsgVsego = 0;
        public int nmrSledBuf = 0;
        public int klvUspPer = 0;
        public int klvInBuf = 0;
        public decimal[,] msgs; // это и есть буфер у каждого сообщения
        public int nmrPoslUsp = -1; // номер последнего успешного
        public int dobVPoslOkne = 0;
        public decimal timeMsgAll = 0;
        
      
        

        // for methods to optimizations
        int nomer_ojid;

        int kolvo;
        int number;
        public Customer(int msg_number, string name)
        {
            klvMsgVsego = msg_number;
            this.name = name;
            msgs = new decimal[msg_number, 4];
            for (int i = 0; i < klvMsgVsego; i++)
            {
                msgs[i, 1] = 0; // 1 - состояние : 0 - ни как не фигируровало 1 - в буфере личном 2- в конвеере 3- отослано
                msgs[i, 0] = 0; // 0 время в конвеере
                msgs[i, 2] = 0; // 2 - в каком окне это сообщение отправлено 1 - в предыдущем, 2 - в этом
                msgs[i, 3] = 0; // если брак сообщения, то еденица
            }
        }
    
        public int getKolvoOtpravlennih()
        {
            if (this.getIfSender()) return (klvInBuf - 1);
            return klvInBuf;
        }

        public int getNomerOjidaemogo()
        {
            nomer_ojid = -1;
            if (!(nmrSledBuf == 0)) {
                if (msgs[nmrPoslUsp + 1, 1] == 2) nomer_ojid = nmrPoslUsp + 2;
                else { nomer_ojid = nmrPoslUsp + 1; }
            } else { nomer_ojid = 0;
            }
            return nomer_ojid;
        }

        public int getNomerOtpravlennogo()
        {
            if (msgs[nmrPoslUsp + 1, 1] == 2)
            {
                return (nmrPoslUsp + 1);
            }else if(msgs[nmrPoslUsp + 2, 1] == 2) return (nmrPoslUsp + 2);

            else { return -1; }

        }

        public int getKolvoYjePrinyatih()
        {
            return klvUspPer;
        }
        public bool getIfSender() //approved
        {
            bool res = false;
            if (msgs[nmrPoslUsp + 1, 1] == 2 || msgs[nmrPoslUsp + 2, 1] ==2)
                res = true;
            return res;
        }
        
        public int getNomerPoslednegoYspeshnoPeredannogo()
        {
            return this.nmrPoslUsp;
        }

    }
}


