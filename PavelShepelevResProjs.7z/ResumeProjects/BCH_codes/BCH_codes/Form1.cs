﻿// Данная работа является курсовым проектом студента ГУАП Шепелева П.К. за 
// 3 курс по курсу Теория Кодирования,2018г.
// Тема: Построение БЧХ кода с декодером по алгоритму Питерсона.
// Курс проходил под руководством Беззатеева Сергея Валентиновича.
//
//
//
//
//Прим : Также были написаны тесты, позволяющее проверить работоспособность программы.
//
//
//
//
//
//
//
//
//

























using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace BCH_codes
{

    public partial class Form1 : Form
    {
        int[] genMatrx = new int[7];
        static int codeLengthN = 31; // Code Length ; All code parameters
        static int messageBits = 11;
        static int checkBits = codeLengthN - messageBits; //
        static int klvErr = 5;

        static string genPoly = "1000111110101111";//."10100110111"; - 15,5,7
        public static string polyForDecoding = "110111";
        static string[] tableOfVals;
        static string[] syndromes = new string[klvErr * 2];
        static string[] alphabetTable = new string[26];
        string errString = "11001000000"; // 10000100 - one that worked

        public Form1()
        {
            InitializeComponent();
            tableOfVals = new string[codeLengthN];
            textBox3.Text = errString;
            createTableOfVals(tableOfVals);
            createAlphabet(alphabetTable);
        }

        private void createAlphabet(string[] alphabetTable) // checked
        {
            int i = 0;
            for (char c = 'a'; c <= 'z'; c++) {
                alphabetTable[i] = Convert.ToString(c);
                i++;
            }
        }
        private string getFromAlphabetTable(char c) { // checked
            string res = "";
            for (int i = 0; i < alphabetTable.Length; i++) {
                if (Convert.ToChar(alphabetTable[i]) == c) {
                    res = Convert.ToString(i, 2);
                }
            }
            return res;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            string enteredText = textBox1.Text;
            for (int i = 0; i < enteredText.Length; i++)
            {
                char curChar = enteredText[i];
                string val = getFromAlphabetTable(curChar);
                if (val == "") return;
                int res = Encode(Convert.ToString(Convert.ToInt32(val,2), 2)); // должно быть верно
                string resAsString = Convert.ToString(res, 2);

                Decode(resAsString);
            }
        }

        private void Decode(string resAsString)
        {
            MatrixInversion MxInv = new MatrixInversion(codeLengthN,messageBits,checkBits,tableOfVals);
            //   string reversed = Reverse(resAsString);
            resAsString = createZeros(codeLengthN - resAsString.Length) + resAsString;
            string infBits = resAsString.Substring(0, messageBits);
            if (Convert.ToInt32(polyDivisionGF2(resAsString, genPoly), 2) == 0)
            {
                textBox2.Text +=  alphabetTable[ Convert.ToInt32(infBits,2)];
            }
            else {
                int counter = 0;
                string ans = "";
                int tmp = 0;
                //  evaluating syndromes
                syndromes = CalculateSindromes(syndromes, resAsString); // синдромы верно
                string[][] mx = new string[klvErr][];
                for (int i = 0; i < klvErr; i++)
                {
                    mx[i] = new string[klvErr];
                }
                int syndrCnt = 0;
                for (int i = 0; i < klvErr; i++)
                {
                    syndrCnt = i;
                    for (int w = 0; w < klvErr; w++) 
                    {
                        string sndAsString = syndromes[syndrCnt]; // вся математика в интах
                        mx[i][w] = sndAsString;
                        syndrCnt++;
                    }
                } // готовая матрица синдромов string. checked для 3х3
                int v = klvErr;
                string[][] inverse = new string[v][];
                // проверяю, есть ли обратная
                for (v = klvErr; v > 0; v--)
                {
                    string[][] cutted =  MxInv.cutMatrix(mx, v);                         // строится верно 
                    int det = MxInv.determinant(cutted);                                          // 0 выдал 1 раз правильно, мб совпадение
                    if (det == 0) continue; 
                    inverse = MxInv.inverseMatrix(cutted);                            // дала правильный результат на 2х2 из примера, что доказывает, что -s1 = s1
                    break;
  //obsolete    //    if ((inverse[0][0] == "-1") && (inverse[1][0] == "-1") && (inverse[1][1] == "-1"))// рандомно проверил значения, значит 0 детерминант
                //    {
                //        continue;
                //    }
                //    else
                //        break; // выход из цикла
                }
                // когда есть обратная матрица - следует умножить её на вектор отрицательных синдромов(щас предполагается, что отриц. синдром == положит. синдром)
                // вектор, на который умножать
                string[][] minusSyndromes = new string[v][]; // инициализация
                for (int i = 0; i < v; i++) {
                    minusSyndromes[i] = new string[1]; 
                }
                for (int i = 0; i < v; i++)
                {
                    for(int w = 0; w < 1; w++)
                    minusSyndromes[i][w] = syndromes[v + i];
                }

                string[][] linRes = MxInv.solveLinear(inverse, minusSyndromes); // для примера решило правильно
                // в зависимости от того, сколько неизвестных - разные уравнения
                string res = "";
                char[] fin = new char[codeLengthN];
                if (v == 3) {
                    string par3 = linRes[0][0];
                    string par2 = linRes[1][0];
                    string par1 = linRes[2][0]; // последний

                    
                    for (int i = 0; i < tableOfVals.Length; i++)
                    {
                        int resInt = -1;
                        string curValFromTable = tableOfVals[i];
                        // depending on V:
                        //string xForPar3Tripled = Form1.polyMultiplInGF2_WithDiv(Form1.polyMultiplInGF2_WithDiv(curValFromTable, curValFromTable), curValFromTable);
                        //string xForPar2Squared = Form1.polyMultiplInGF2_WithDiv(curValFromTable, curValFromTable);
                        //string xForPar1 = curValFromTable;

                        int par1Pos = GetPositionAtTable(par1);
                        int par2Pos = GetPositionAtTable(par2);
                        int par3Pos = GetPositionAtTable(par3);

                        string fPart = "";
                        string sPart = "";
                        string thPart = "";
                        if (par1Pos == -1)
                        {
                            fPart = "0";
                        }
                        else { fPart = tableOfVals[(par1Pos + (i)) % codeLengthN]; }
                        if (par2Pos == -1)
                        {
                            sPart = "0";
                        }
                        else { sPart = tableOfVals[(par2Pos + (i + i)) % codeLengthN]; }
                        if (par3Pos == -1)
                        {
                            thPart = "0";
                        }
                        else { thPart = tableOfVals[(par3Pos + (i + i + i)) % codeLengthN]; }

                                   // тут поменяв математику на табличную дал хотя бы одну еденицу
                        resInt = 1 ^ Convert.ToInt32(fPart , 2) ^
                                     Convert.ToInt32(sPart , 2) ^
                                     Convert.ToInt32(thPart , 2);                                             
                        if (resInt != 0)
                        {
                            //  ans += "0";
                            fin[i] = Convert.ToChar("0");
                        }
                        else
                        {
                            //   ans += "1";
                            fin[i] = Convert.ToChar("1");
                        }

                    }
               //     ans = Reverse(ans);
                }
                if (v == 2)
                {
                    string par2 = linRes[0][0];
                    string par1 = linRes[1][0]; // последний

                 //int   resInt = 1 ^ Convert.ToInt32(Form1.polyMultiplInGF2_WithDiv(par1, "0"), 2) ^
                 //                    Convert.ToInt32(Form1.polyMultiplInGF2_WithDiv(par2, "0"), 2);
                 //   if (resInt != 0)
                 //   {
                 //       ans += "0";
                 //   }
                 //   else
                 //   {
                 //       ans += "1";
                 //   }

                    for (int i = 0; i < tableOfVals.Length; i++)
                    {
                        int resInt = -1;
                        string curValFromTable = tableOfVals[i];
                        
                        // depending on V:
                       
                        string xForPar2Squared =  tableOfVals [    (i + i) % 15        ] ; // так же , как и с полиномами
                        string xForPar1 = curValFromTable;
                        int par1Pos = GetPositionAtTable(par1);
                        int par2Pos = GetPositionAtTable(par2);

                        string fPart = "";
                        string sPart = "";
                       
                       
                        if (par1Pos == -1)
                        {
                            fPart = "0";
                        }
                        else { fPart = tableOfVals[(par1Pos + (i)) % codeLengthN]; }

                        if (par2Pos == -1)
                        {
                            sPart = "0";
                        }
                        else { sPart = tableOfVals[(par2Pos + (i + i)) % codeLengthN]; }

                       
                        resInt = 1 ^ Convert.ToInt32( fPart ,2 ) ^
                                     Convert.ToInt32( sPart , 2);      
                        if (resInt != 0)
                        {
                            fin[i] = Convert.ToChar("0");
                         //   ans += "0";
                        }
                        else
                        {
                        //    ans += "1";
                            fin[i] = Convert.ToChar("1");
                        }

                    }
               //     ans =  Reverse(ans);
                }
                if (v == 1)
                {
                    string par1 = linRes[0][0]; // последний
                   
                    for (int i = 0; i < tableOfVals.Length; i++)
                    {
                        int resInt = -1;
                        string curValFromTable = tableOfVals[i];
                        int par1Pos = GetPositionAtTable(par1);
                       
                        string fPart = "";
                        if (par1Pos == -1)
                        {
                            fPart = "0";
                        }
                        else { fPart = tableOfVals[(par1Pos + (i)) % codeLengthN]; }
              
                        resInt = 1 ^ Convert.ToInt32(fPart, 2);
                        if (resInt != 0)
                        {
                          //   ans += "0";
                            fin[  i] = Convert.ToChar("0");
                        }
                        else
                        {
                          //    ans += "1";
                            fin[i] = Convert.ToChar("1");
                        }

                    }
                //    ans = Reverse(ans);
                } // надо взять обратные значения т .е у меня ответ a^8 и a^13 - тогда ответы 7 и 2

                ans = new string(fin);
                ans = getInversePosition(ans);
                ans = Reverse(ans);
                ans = Convert.ToString(Convert.ToInt32(ans, 2), 2); // убираем лишние нули
                
                int ansF = Convert.ToInt32(ans, 2) ^ Convert.ToInt32(resAsString, 2); // ксорю с входным вектором
                string ansFAsString = Convert.ToString(ansF, 2);
                ansFAsString = createZeros(codeLengthN - ansFAsString.Length) + ansFAsString;
                infBits = ansFAsString.Substring(0, messageBits);
                textBox2.Text += alphabetTable[Convert.ToInt32(infBits, 2)]; // отображаю

                // только для 2-х ошибок
                //// решаю уравнение
                //string S3S1 = "";
                ////XY = S2 - S3 /S1 . Attention: возможно, что имеется ввиду, когда S3/S1 - место в таблице.
                //if
                //    (Convert.ToInt32(syndromes[2], 2) == 0) { S3S1 = "0"; }
                //else
                //    S3S1 = tableOfVals[ (GetPositionAtTable(  syndromes[2]) - GetPositionAtTable(syndromes[0]) + codeLengthN) % codeLengthN];

                //int XY = Convert.ToInt32(syndromes[1], 2) ^ Convert.ToInt32(S3S1, 2);
                //string XY_asString = Convert.ToString(XY, 2);
                ////  string XY_asString = rs;
                //// место ошибок
                //for (int i = 0; i < tableOfVals.Length; i++) {
                //    int resLoc = -1;
                //    string curValFromTable = tableOfVals[i];
                //    resLoc = Convert.ToInt32(polyMultiplInGF2_WithDiv(curValFromTable, curValFromTable), 2) ^ Convert.ToInt32(polyMultiplInGF2_WithDiv(syndromes[0], curValFromTable), 2) ^ Convert.ToInt32(XY_asString, 2); // с w13 проверка
                //    if (resLoc != 0)
                //    {
                //        ans += "0";
                //    }
                //    else {
                //        ans += "1";
                //    }

                //}
                //ans = Reverse(ans);
                //ans = Convert.ToString(Convert.ToInt32(ans, 2), 2);
                //int ansF = Convert.ToInt32(ans, 2) ^ Convert.ToInt32(resAsString, 2);
                //string ansFAsString = Convert.ToString(ansF, 2);

                //infBits = ansFAsString.Substring(0, messageBits);
                //textBox2.Text += Convert.ToChar(Convert.ToInt32(infBits, 2));
            }
        }

        private string getInversePosition(string ans) // даёт нужный результат по логике 01....00 -> 00...10
        {
            string res = "0";
            string tmp = "";
            char[] wordFinal = new char[ans.Length];
            for (int i = 0; i < ans.Length; i++) {
                wordFinal[i] = Convert.ToChar("0");
            }
            for (int i = 0; i < ans.Length; i++) {
                tmp = "";
                
                if (Convert.ToString(ans[i]) == "1") {
                    
                    wordFinal[ (codeLengthN - i) %codeLengthN  ] = Convert.ToChar("1");
                }

            }
            res = new String(wordFinal);
            return res;
        }

        private string[] CalculateSindromes(string[] syndromes, string resAsString) // should be right
        {
            string[] sndrs = new string[syndromes.Length];
            for (int i = 0; i < syndromes.Length; i++)
            {
                string ev = evaluateInRoot(resAsString, i + 1);
                sndrs[i] = Convert.ToString(Convert.ToInt32(polyDivisionGF2(ev, polyForDecoding), 2), 2);
            }
            return sndrs;
        }

        public static string polyMultiplInGF2_WithDiv(string curValFromTable1, string curValFromTable2)
        {
            var res = polyDivisionGF2(polyMultiplInGF2(curValFromTable1, curValFromTable2), polyForDecoding);
            return res;
        }

        public int Encode(string encWord) // проверил
        {
            string stratWord = encWord;
            int stratWInt = Convert.ToInt32(stratWord, 2) << checkBits;
       //      stratWord = createZeros(  messageBits - encWord.Length  ) + encWord;
             encWord = Convert.ToString(Convert.ToInt32(encWord, 2), 2);
            encWord = Convert.ToString(Convert.ToInt32(encWord, 2) << checkBits, 2); // length of a word already
            string ans = polyDivisionGF2(encWord, genPoly);
            ans = createZeros( checkBits - ans.Length) + ans; //codeLengthN - (stratWord.Length + ans.Length)
            string res = Convert.ToString(  stratWInt ^ Convert.ToInt32( ans,2)   ,2);
            // добавлю прямо тут ошибку в 0 и в 13 бите
            string err = Convert.ToString(textBox3.Text);
            res = Convert.ToString(Convert.ToInt32(res, 2) ^ Convert.ToInt32(err, 2), 2);
            return Convert.ToInt32(res, 2);
        }

        public int[] createGenMatrx(string genPoly)
        {
            if (genPoly.Length > codeLengthN) return new int[0];
            string genPolyStarted = genPoly;
            int genPolyAsInt = Convert.ToInt32(genPoly, 2) << (codeLengthN - genPolyStarted.Length);
            genPoly = Convert.ToString(genPolyAsInt, 2);
            int[] genMatrix = new int[genPoly.Length - genPolyStarted.Length + 1];

            for (int i = 0; i < genPoly.Length - genPolyStarted.Length + 1; i++)
            {
                genMatrix[i] = Convert.ToInt32(genPoly, 2) >> i;
                string strRep = Convert.ToString(genMatrix[i], 2);
            }
            return genMatrix;
        }

        public static string polyDivisionGF2(string begPoly, string divPoly) { // проверил
            begPoly = Convert.ToString(Convert.ToInt32(begPoly, 2), 2);
            divPoly = Convert.ToString(Convert.ToInt32(divPoly, 2), 2);
            if (begPoly == divPoly) { return "0"; }
            if (divPoly == "1") return begPoly;
            if (divPoly.Length > begPoly.Length) // если степень делимого меньше, то не делим
                return begPoly;
            int curPos = divPoly.Length;
            string bitsForNextRound = Convert.ToString(Convert.ToInt32(begPoly.Substring(0, divPoly.Length), 2), 2);
            int i = 1;
            int temp = 0;
            while (bitsForNextRound.Length == divPoly.Length)
            {
                // string firstPart = begPoly.Substring(0, divPoly.Length); // первые символы(наибольшие) в числе
                int partAsInt = Convert.ToInt32(bitsForNextRound, 2);
                int divPolyAsInt = Convert.ToInt32(divPoly, 2);
                int res = partAsInt ^ divPolyAsInt;
                string adBits = "";
                string resAsString = Convert.ToString(res, 2);
                if (resAsString.Length < divPoly.Length && curPos < begPoly.Length)
                {
                    if (curPos + (divPoly.Length - resAsString.Length) >= begPoly.Length)
                    {
                        temp = begPoly.Length - curPos;
                    }
                    else
                    {
                        temp = divPoly.Length - resAsString.Length;
                    }
                    adBits = begPoly.Substring(curPos, temp);
                }
                curPos = curPos + adBits.Length;
                bitsForNextRound = resAsString + adBits; // зациклить
                i++;
            }
            begPoly = bitsForNextRound;
            //    textBox1.Text += "\n " + begPoly;
            begPoly = Convert.ToString(Convert.ToInt32(begPoly, 2), 2);
            return begPoly;
        }


        public static string polyMultiplInGF2(string poly1, string poly2) {
            if (poly1.Length < poly2.Length) {
                var temp = poly1;
                poly1 = poly2;
                poly2 = temp;
            }
            poly2 = Reverse(poly2);
            int curBits = 0;
            string addBits = "";
            int poly1AsInt = Convert.ToInt32(poly1, 2);
            string curBitsAsString = "";
            for (int i = 0; i < poly2.Length; i++) {
                if (Convert.ToInt32(poly2.Substring(i, 1)) == 1) {
                    curBits ^= Convert.ToInt32(poly1, 2);
                }
                poly1 = Convert.ToString(Convert.ToInt32(poly1, 2) << 1, 2);
                curBitsAsString = Convert.ToString(curBits, 2);
            }
            int ans = curBits;
            return Convert.ToString(curBits, 2);
            // textBox2.Text += Convert.ToString(curBits,2);
        }
        public static string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        public string createZeros(int numberOfZeros) {
            string str = "";
            for (int i = 0; i < numberOfZeros; i++) {
                str += "0";
            }
            return str;
        }
        // создаёт матрицу стандартного вида в формате string
        public string[] showGenMatrix(int[] genMatrixInt) {
            string[] genMatrixString = new string[genMatrixInt.Length];
            for (int i = 0; i < genMatrixInt.Length; i++) {
                string elementAsString = Convert.ToString(genMatrixInt[i], 2);
                if (elementAsString.Length < codeLengthN) {
                    elementAsString = createZeros(codeLengthN - elementAsString.Length) + elementAsString;
                }
                textBox3.Text += "\t " + elementAsString + "\r\n";
                genMatrixString[i] = elementAsString;
            }
            return genMatrixString;
        }

        public static string evaluateInRoot(string givenPoly, int expOfRoot) { // даёт правильный ответ без замены через таблицу
            string res = "";
            givenPoly = Convert.ToString(Convert.ToInt32(givenPoly, 2), 2);
            givenPoly = Reverse(givenPoly);
            string newPolyReversed = "";
            newPolyReversed = Convert.ToString(givenPoly[0]);
            for (int i = 1; i < givenPoly.Length; i++) {
                if (givenPoly[i] == '1') {
                    string bits = "1";
                    int hmToShift = 0;
                    hmToShift = expOfRoot * i % (codeLengthN); // так, да? - длина кода, по сути, пока что messageBits заменяют длину кода
                    int shiftedBits = Convert.ToInt32(bits) << (hmToShift);
                    string ans = Convert.ToString(shiftedBits, 2);
                    newPolyReversed = Convert.ToString(Convert.ToInt32(newPolyReversed, 2) ^ Convert.ToInt32(ans, 2), 2);
                }
            }
            string poly = newPolyReversed;
            res = poly;


            return res;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            runTest();
        
        }
        public void createTableOfVals(string[] tableOfVals) {
         //    tableOfVals[0] = "0";
            for (int i = 0; i < tableOfVals.Length; i++) {
                string el = "";
                el = polyDivisionGF2(Convert.ToString(1 << (i), 2), polyForDecoding);
                tableOfVals[i] = el;
            }
        
        }
        public static string polyDivisionGF2_stdAnsw(string begPoly, string divPoly)
        {
            string ansAsString = "0";
            int ansAsInt = 0;
            begPoly = Convert.ToString(Convert.ToInt32(begPoly, 2), 2);
            divPoly = Convert.ToString(Convert.ToInt32(divPoly, 2), 2);
            if (divPoly.Length > begPoly.Length) // если степень делимого меньше, то не делим
                return ansAsString;
            int curPos = divPoly.Length;
            int toShift = (begPoly.Length - divPoly.Length);
            string bitsForNextRound = Convert.ToString(Convert.ToInt32(begPoly.Substring(0, divPoly.Length), 2), 2);
            int i = 1;
            int temp = 0;

            while (bitsForNextRound.Length == divPoly.Length)
            {
                /*if (i == 1) { ansAsInt = 1; } */// инициализация только если

                // string firstPart = begPoly.Substring(0, divPoly.Length); // первые символы(наибольшие) в числе
                int partAsInt = Convert.ToInt32(bitsForNextRound, 2);
                int divPolyAsInt = Convert.ToInt32(divPoly, 2);
                int res = partAsInt ^ divPolyAsInt;
                string adBits = "";
                string resAsString = Convert.ToString(res, 2);
                if (i == 1) { ansAsInt = ansAsInt ^ 1; }

                if (resAsString.Length < divPoly.Length && curPos < begPoly.Length)
                {
                    if (curPos + (divPoly.Length - resAsString.Length) >= begPoly.Length)
                    {
                        temp = begPoly.Length - curPos;
                    }
                    else
                    {
                        temp = divPoly.Length - resAsString.Length;
                    }
                    adBits = begPoly.Substring(curPos, temp);
                    ansAsInt = (1 << toShift) ^ ansAsInt;
                    ansAsString = Convert.ToString(ansAsInt, 2);
                }
                curPos = curPos + adBits.Length;
                bitsForNextRound = resAsString + adBits; // зациклить
                i++;
                toShift = begPoly.Substring(curPos).Length;
            }
            begPoly = bitsForNextRound;
            //    textBox1.Text += "\n " + begPoly;
            ansAsString = Convert.ToString(ansAsInt, 2);
            return ansAsString;
        }

        public int GetPositionAtTable(string word)
        {
            if (word == "0") { return -1; }
            int pos = -1;
            for (int i = 0; i < tableOfVals.Length; i++)
            {
                if (tableOfVals[i] == word)
                {
                    pos = i;
                    break;
                }
            }
            return pos;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "a";
            textBox2.Text = "";
        }
        // Примечание!!! Данный метод работает только с БЧХ длинной 15, т.к. написал был под него.
        // Для получения кода длинной 15 следует задать нужные параметры и нужный generator polynomial.
        public void runTest() {
            int stLength = errString.Length;
            string ERROR_IS = "";
            string str = "1";
            bool errHappened;
            string hmTm = str;
            for (int i = 0; i < 2; i++) {
                if (i > 0) { str = "11";
                    hmTm = str;
                }
                for (int k = 0; k < codeLengthN - i; k++) {
                    textBox2.Text = "";
                    str = Convert.ToString(Convert.ToInt32(hmTm, 2) << k, 2);
                    textBox3.Text = str;
                    button1.PerformClick();
                    if (textBox2.Text != textBox1.Text) {
                        errHappened = true;
                    }
                }
            } // проверено
            for (int i = 0; i < codeLengthN; i++)
            {
                int whatToMove = 1 << i;
                string wtAsString = Convert.ToString(whatToMove, 2);
                for (int w = 0; w < wtAsString.Length; w++)
                {
                    int res = whatToMove ^ (1 << w);
                    str = Convert.ToString(res, 2);
                    textBox2.Text = "";
                    textBox3.Text = str;
                    button1.PerformClick();
                    if (textBox2.Text != textBox1.Text)
                    {
                        errHappened = true;
                        ERROR_IS = str;
                    }
                }

            } // проверено
            // 3 ошибки
            for (int i = 0; i < codeLengthN - 1; i++) {
                int whatToMove = 3 << i;
                string wtAsString = Convert.ToString(whatToMove, 2);
                for (int w = 0; w < wtAsString.Length - 2; w++)
                {
                    int res = whatToMove ^ (1 << w);
                    str = Convert.ToString(res, 2);
                    textBox2.Text = "";
                    textBox3.Text = str;
                    button1.PerformClick();
                    if (textBox2.Text != textBox1.Text)
                    {
                        errHappened = true;
                        ERROR_IS = str;
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

    // матрица на входе состоит из номером из синдромов
    public class MatrixInversion {
        static int codeLengthN = 15; // Code Length
        int messageBits = 5;
        int checkBits = 10;
      static  string[] tableOfVals = new string[codeLengthN];

        public MatrixInversion(int codeLengthN2, int messageBitS, int checkBits, string[] tableOfValS) {
            codeLengthN = codeLengthN2;
            messageBits = messageBitS;
            this.checkBits = checkBits;
            tableOfVals = tableOfValS;
        }



        public string[][] TransposeMatrix(string[][] mx) // adapted
        {
            string[][] newMx = new string[mx.Length][];
            createDeepCopy(mx, newMx);
            for (int i = 0; i < mx.Length; i++) //i - строка  w - столбец 
            {
                for (int w = 0; w < mx[i].Length; w++)
                {
                    newMx[i][w] = mx[w][i];
                }

            }
            return newMx;
        }
        public string[][] matrixOfMinors(string[][] mx)
        { // дало верный результат на 3 на 3 матрицу. Также положительный результат 4 на 4
            string[][] newMx = new string[mx.Length][];
            createDeepCopy(mx, newMx);
            int det = -1;
            if (mx.Length == 1)
            {
                newMx[0][0] = mx[0][0];
            }
            if (mx.Length == 2) // выглядит верно
            {
                newMx[0][0] = mx[1][1];
                newMx[0][1] = mx[1][0];
                newMx[1][0] = mx[0][1];
                newMx[1][1] = mx[0][0];
            }
            if (mx.Length > 2)
            {
                for (int i = 0; i < mx.Length; i++) //i - строка  w - столбец 
                {
                    for (int w = 0; w < mx[i].Length; w++)
                    {
                        newMx[i][w] = minor(i, w, mx);
                    }
                } // находится детерминант матрицы начальной
            }
            createCofactorMatrix(newMx);
            return newMx;
        }

        private string minor(int i, int w, string[][] mx) //i - строка  w - столбец 
        {
            string[][] mxStarted = new string[mx.Length][];
            createDeepCopy(mx, mxStarted);

            string res = "";
            int rowCounter = 0;
            int columnCounter = 0;
            string[][] mxOutRC = new string[mx.Length - 1][]; // mxOutRC mx without row and column
            // создаю матрицу без данной строки и столбца
            for (int q = 0; q < mx.Length; q++)
            {
                if (q == i) continue;
                mxOutRC[rowCounter] = new string[mx.Length - 1];
                columnCounter = 0;
                for (int k = 0; k < mx[q].Length; k++)
                {
                    if (k == w) continue;
                    mxOutRC[rowCounter][columnCounter] = mxStarted[q][k];
                    columnCounter++;
                }
                rowCounter++;
            } // ВЕРНО убрал  ИЗ 4x4 матрицы строку и столбец
            res = Convert.ToString (determinant(mxOutRC) , 2); // детерминант возвращает интовое значение
            return res;
        }

        private void createCofactorMatrix(string[][] mx) // проверено
        {
            for (int i = 0; i < mx.Length; i++)
            {
                for (int w = 0; w < mx[i].Length; w++)
                {
                    if (i % 2 == 0 && w % 2 == 1 || i % 2 == 1 && w % 2 == 0)
                    { // конструкция ниже предполагает, что -s1 = s14
                        mx[i][w] = mx[i][w];  // tableOfVals[ ((- GetPositionAtTable( mx[i][w] ) ) + codeLengthN ) % codeLengthN] ; // !!! минус здесь что значит? Что меняется из 13 на -13, или остается таким же?
                    }                         // Вернуть - mx[i][w] если -s1 != s1  
                }
            }
        }

        public int determinant(string[][] mx) // проверено
        { // дало верный результат на 3 на 3 матрицу.
            string[][] newMx = new string[mx.Length][];
            createDeepCopy(mx, newMx);
            int k = 0;
            int det = 0;
            int finMultp = 0;
            int mulp1 = 0;
            int mulp2 = 0;
            int fPart = 0;
            int sPart = 0;
            int thrPart = 0;
            int thPart = 0;

            string st1 = "";
            string st2 = "";
            if (mx.Length == 1)
            {
                det = Convert.ToInt32(mx[0][0],2); // детерминант не важен тут, можно это же число вернуть
            }
            if (mx.Length == 2) // для двух считается пр
            {
                fPart = GetPositionAtTable(  mx[0][0]  );
                sPart = GetPositionAtTable(mx[1][1]);
                thrPart = GetPositionAtTable(mx[1][0]);
                thPart = GetPositionAtTable(mx[0][1]); 
                if (fPart == -1 || sPart == -1) // проверка синдромов на нули
                {
                    mulp1 = -1;
                    st1 = "0";
                }
                else {
                    mulp1 = (codeLengthN + fPart + sPart) % codeLengthN;
                    st1 = tableOfVals[mulp1];
                }
                if (thrPart == -1 || thPart == -1)
                {
                    mulp2 = -1;
                    st2 = "0";
                }
                else {
                    mulp2 = (codeLengthN + thPart + thrPart) % codeLengthN;
                    st2 = tableOfVals[mulp2];
                }
                

                det = Convert.ToInt32(st1,2) ^ Convert.ToInt32(st2,2); // должно работать
            }
            if (mx.Length > 2)
            {
                for (int i = 0; i < 1; i++) //i - строка  w - столбец 
                {
                    for (int w = 0; w < mx[i].Length; w++)
                    {
                        if (i % 2 == 0 && w % 2 == 1 || i % 2 == 1 && w % 2 == 0)
                            k = 1; // здесь вернуть на k - 1, если -s1 != s1
                        else k = 1;
                        // 
                        fPart = GetPositionAtTable(mx[i][w]);
                        sPart = GetPositionAtTable( minor(i, w, mx)  );

                        if (fPart == -1 || sPart == -1)
                        {
                            finMultp = 0;
                            st1 = "0";
                        }
                        else {
                            finMultp = (fPart + sPart) % codeLengthN;
                            st1 = tableOfVals[finMultp];

                        }

                            det ^= Convert.ToInt32(st1, 2);
                      
                    }
                } // находится детерминант матрицы начальной
                // newMx - матрица миноров
            }
            return det;
        }

        public string[][] inverseMatrix(string[][] mx) // пока что предполагается, что матрица квадратная
        {
            string[][] res;
            int dtr = determinant(mx);
            if (dtr == 0)
            {
                throw new OutOfMemoryException();
            }
            res = matrixOfMinors(mx); // should be good at least for 2x2
            res = TransposeMatrix(res);
            string[][] resAsInt = mltByDeterminant(dtr, res);
            return resAsInt;
        }

        public string[][] mltByDeterminant(int determenant, string[][] mx) // adapted
        {
            string[][] newMx = new string[mx.Length][];
            createDeepCopy(mx, newMx);
            string detAsString = Convert.ToString(determenant, 2);

            if (detAsString == mx[0][0] && mx.Length == 1)
            {
                int fPart = GetPositionAtTable(mx[0][0]);
                if (fPart == -1) {
                    throw new OutOfMemoryException(); // не должен оказаться здесь - значит, что синдром нулевой - т.е. ошибок нет. Если их нет - сюда не попасть.
                }
                   newMx[0][0] =  tableOfVals[ (codeLengthN + (  codeLengthN - GetPositionAtTable(mx[0][0]) ) )  % codeLengthN ]; // попытка вернуть обратное значение данному
              //  newMx[0][0] = mx[0][0];
                return newMx;
            }
            
            for (int i = 0; i < mx.Length; i++) //i - строка  w - столбец 
            {
                for (int w = 0; w < mx[i].Length; w++)
                {
                   int tmp1 = GetPositionAtTable(mx[i][w]);
                   int tmp2 = GetPositionAtTable(detAsString);
                    int multp = 0;
                    if (tmp1 == -1) { newMx[i][w] = "0"; continue; }
                    else if (tmp2 == -1)
                    {
                        throw new OutOfMemoryException(); // если есть - значит детерминант нулю равен

                            /* не должно быть по сути, но мало ли */
                    }
                    else {
                        multp = (codeLengthN + (tmp1 - tmp2)) % codeLengthN;
                    }


                    newMx[i][w] = tableOfVals [multp] ;
                //    newMx[i][w] = Form1.polyDivisionGF2(mx[i][w], detAsString); //        (determenant + mx[i][w]) % determenant; // чтобы в минус не ушло                                                       //  textBox1.Text += mx[i][w] + "/" + determenant + "    |||    ";
                }
                //   textBox1.Text += "\r\n\r\n";

            }
            return newMx;
        }

        public void createDeepCopy(string[][] org, string[][] copy) // проверено
        {
            for (int i = 0; i < org.Length; i++)
            {
                copy[i] = new string[org.Length];
                for (int w = 0; w < copy.Length; w++)
                {
                    copy[i][w] = org[i][w];
                }
            }
        }

        public void createDeepCopy(int[][] org, int[][] copy) // проверено
        {
            for (int i = 0; i < org.Length; i++)
            {
                copy[i] = new int[org.Length];
                for (int w = 0; w < copy.Length; w++)
                {
                    copy[i][w] = org[i][w];
                }
            }
        }
        public string[][] solveLinear(string[][] mx, string[][] ans) // adapted
        {
            
            // float[][] invt = inverseMatrix(mx);
            string[][] res = new string[mx.Length][];
            for (int i = 0; i < ans.Length; i++)
            {// инициализация
                res[i] = new string[ans[0].Length];
            }
            int cntr = 0;
            int tmp = 0;
            for (int i = 0; i < mx.Length; i++)
            {
                for (int k = 0; k < ans[i].Length; k++)
                {
                    tmp = 0;
                    for (int w = 0; w < mx[i].Length; w++)
                    {
                        //    string mxString = Convert.ToString(mx[i][w], 2); // здесь поменять на табличную математику
                        string tempr = "0";// =    Form1.polyMultiplInGF2_WithDiv( mx[i][w],ans[w][k]); //tableOfVals[(codeLengthN + GetPositionAtTable(mx[i][w]) + GetPositionAtTable(ans[w][k])) % codeLengthN];
                                     //    string ansString = Convert.ToString(ans[w][k], 2);
                                     //    string rst = Form1.polyMultiplInGF2_WithDiv(mxString, ansString);

                       
                        int fPart = (GetPositionAtTable(mx[i][w]));
                        int sPart = GetPositionAtTable(ans[w][k]);
                        int mult = 0;
                        if (fPart == -1 || sPart == -1)
                        {
                            mult = 0;
                            tempr = "0";
                        }
                        else {
                            mult = (fPart + sPart) % codeLengthN;
                            tempr = tableOfVals[mult];
                        }
                        
                        int temprInt  = Convert.ToInt32(tempr,2);
                        tmp ^= temprInt;     // Convert.ToInt32(rst);
                    }
                    res[i][k] = Convert.ToString(tmp,2);
                }

                //cntr++;
                //if (cntr % ans[0].Length == 0) cntr = 0;
            }
            return res;
        }

        internal string[][] cutMatrix(string[][] mx, int dimensions) // checked: for 3x3, for 2x2
        {
            string[][] newMx = new string[dimensions][];
            for (int i = 0; i < dimensions; i++)
            {
                newMx[i] = new string[dimensions];
            }
            for (int i = 0; i < dimensions; i++)
            {
                for (int w = 0; w < dimensions; w++)
                {
                    newMx[i][w] = mx[i][w];
                }
            }
            return newMx;
        }
      static   public int GetPositionAtTable(string word)
        {
            if (word == "0") { return -1; }
            int pos = -1;
            for (int i = 0; i < tableOfVals.Length; i++)
            {
                if (tableOfVals[i] == word)
                {
                    pos = i;
                    break;
                }
            }
            return pos;
        }

    }


}
