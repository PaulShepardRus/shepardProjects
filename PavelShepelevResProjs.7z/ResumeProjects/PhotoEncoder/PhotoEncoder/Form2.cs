﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotoEncoder
{
    public partial class Form2 : Form
    {
        Bitmap image = new Bitmap(100,100);
        public Form2()
        {
            InitializeComponent();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
        public void setImage(Bitmap img) {
            this.image = img;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            chart1.Series[0].Points.Clear();
            //    Bitmap graph = new Bitmap(500,500);
          //  Bitmap image = new Bitmap(pictureBox1.Image);
            for (int i = 0; i < image.Height; i++)
            {
                for (int k = 1; k < image.Width; k++)
                {
                    byte grScale1 = image.GetPixel(k, i).G;
                    byte grScale0 = image.GetPixel(k - 1, i).G;
                    chart1.Series["Dots"].Points.AddXY(grScale0, grScale1);
                }

            }
            getCorrelation(image);
        }
        public void getCorrelation(Bitmap image) {
            double avX = 0;
            double avY = 0;
            for (int i = 0; i < 10; i++) // 1023
            {
                for (int k = 1; k < image.Width; k++) // 767
                {
                    avY += image.GetPixel(k, i).G;
                    avX += image.GetPixel(k - 1, i).G;

                  //  chart1.Series["Dots"].Points.AddXY(grScale0, grScale1);
                }

            }
            avX =  (byte)  ( ( (double) avX ) / ( (double) 10 * image.Width) );
            avY = (byte)(((double)avY) / ((double)10 * image.Width));
                double upperFraction = 0;
            for (int i = 0; i < 10; i++) // 1023
            {
                for (int k = 1; k < image.Width; k++) // 767
                {
                    upperFraction += (image.GetPixel(k - 1, i).G - avX) * (image.GetPixel(k, i).G - avY);

                    //  chart1.Series["Dots"].Points.AddXY(grScale0, grScale1);
                }

            }
            double loweFraction = 0;
            double loweFractionY = 0;
            for (int i = 0; i < 10; i++) // 1023
            {
                for (int k = 1; k < image.Width; k++) // 767
                {
                    loweFraction += (Math.Pow((image.GetPixel(k - 1, i).G - avX), 2));  
                    loweFractionY += ((double)Math.Pow((image.GetPixel(k, i).G - avY), 2));
                    //  chart1.Series["Dots"].Points.AddXY(grScale0, grScale1);
                }
            }
            loweFraction = loweFraction * loweFractionY;
            loweFraction =  Math.Sqrt( (double)loweFraction);
            double res = ( upperFraction ) / loweFraction;

        }
    }
}
