﻿// Данная работа является проектом студента ГУАП Шепелева П.К. за 3 курс по курсу 
// Аппаратные средства защиты информации,2018г.
// Тема: Реализация sp-сети с передаваемым ключом, реализация теста на корреляцию.
// Курс проходил под руководством Окатова Александра Всеволодовича
//
//
//
//
//
//
//
//
//
//
//
//
//
















using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text;
using System.Drawing.Imaging;
using System.Collections;
using System.Windows.Forms.DataVisualization.Charting;


namespace PhotoEncoder
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        Random rnd2 = new Random();
        int nmbOfRound = 20;      // 2 раунда по 3 Sboxa
        int KlvSBOXES = 3;
        StreamWriter sw;
        int[][] revSBoxes;
        int[][] revPBoxes;
        int[][] pBoxes;
        int[][] sBoxes;
        int roundCounter = -1;
       static string src = "D:\\laba\\sasha.jpg";

      

        int blockSize = 8;
        public Form1()
        {
            InitializeComponent();
        }
        // 2 раунда по 3 Sboxa
        private void Form1_Load(object sender, EventArgs e)
        {

            File.WriteAllText("D:\\laba\\Sboxes.csv", "");
            sw = System.IO.File.AppendText("D:\\laba\\Sboxes.csv");
            sBoxes = new int[nmbOfRound * KlvSBOXES][];
            int[] sBox1 = new int[0];
            for (int i = 0; i < nmbOfRound * KlvSBOXES; i++)
            {
                sBox1 = createSBox(i);
                if (sBox1.Length == 0) { i--; continue; }
                sBoxes[i] = sBox1;

            }
            pBoxes = new int[nmbOfRound][];
            for (int i = 0; i < nmbOfRound; i++)
            {
                pBoxes[i] = createPBox();
            }
            revSBoxes = createDecodeSBox(sBoxes);
            revPBoxes = createRevPBoxes(pBoxes);

       //     Encode(10765287);
            
            Bitmap img = new Bitmap(src);

            pictureBox1.Image = img;




        }

        private int Encode(int v)
        {
            //   for (int i = 0; i < nmbOfRound; i++) {
            int[] curSbox = sBoxes[0];
            //    int val = curSbox[v];
            int[] curPbox = pBoxes[0];
            var encoded = encodePBox(curPbox, v);

            // decoding;

            int[] curRevPbox = revPBoxes[0];
            int val = decodePBox(curRevPbox, encoded);
            //int[] curRevSbox = revSBoxes[0];
            //var res = curRevSbox[val];


            //}
            return val;
        }
        private int encodePBox(int[] curPbox, int vle)
        {
            string vleAsString = Convert.ToString(vle, 2);
            vleAsString = Reverse(vleAsString);
            vleAsString += createZeros(KlvSBOXES * 8 - vleAsString.Length);
            char[] encodedWord = new char[vleAsString.Length];
            for (int i = 0; i < vleAsString.Length; i++)
            {
                encodedWord[i] = vleAsString[i];
            }
            for (int i = 0; i < curPbox.Length; i++)
            {
                int numberToChangeWith = curPbox[i];
                encodedWord[numberToChangeWith] = vleAsString[i];
                //encodedWord[i] = tmp;
                //encodedWord[i] = encodedWord[numberToChangeWith];
                //encodedWord[numberToChangeWith] = tmp;
            }
            var wordAsString = new string(encodedWord);
            wordAsString = Reverse(wordAsString);
            int encWord = Convert.ToInt32(wordAsString, 2);
            return encWord;
        }

        private int decodePBox(int[] curRevPbox, int vle)
        {
            string vleAsString = Convert.ToString(vle, 2);
            vleAsString = Reverse(vleAsString);
            vleAsString += createZeros(KlvSBOXES * 8 - vleAsString.Length);
            char[] encodedWord = new char[vleAsString.Length];
            for (int i = 0; i < vleAsString.Length; i++)
            {
                encodedWord[i] = vleAsString[i];
            }
            for (int i = 0; i < curRevPbox.Length; i++)
            {
                int numberToChangeWith = curRevPbox[i];
                encodedWord[numberToChangeWith] = vleAsString[i];
                // encodedWord[i] = tmp;
                //encodedWord[i] = encodedWord[numberToChangeWith];
                //encodedWord[numberToChangeWith] = tmp;
            }
            var wordAsString = new string(encodedWord);
            wordAsString = Reverse(wordAsString);
            int decWord = Convert.ToInt32(wordAsString, 2);
            return decWord;
        }

        private int[][] createRevPBoxes(int[][] pBoxes) // copied
        {
            int[][] revPBoxes = new int[nmbOfRound][];
            for (int i = 0; i < revPBoxes.Length; i++)
            {
                var curBox = new int[KlvSBOXES * 8];
                for (int q = 0; q < curBox.Length; q++)
                {
                    curBox[q] = -1;
                }
                revPBoxes[i] = curBox;
            }
            for (int i = 0; i < revPBoxes.Length; i++)
            {
                int[] curPBox = pBoxes[i];
                int[] curRevPBox = revPBoxes[i];
                for (int q = 0; q < curPBox.Length; q++)
                {
                    int val = curPBox[q];
                    curRevPBox[val] = q;
                }
                revPBoxes[i] = curRevPBox;
            }



            return revPBoxes;


        }

        public int[] createSBox(int pordyadkoviyNomerNaRukave) // copied
        {
            int lim = 3;
            int straightFails = -1;
            int[] sBox = new int[256];
            for (int i = 0; i < sBox.Length; i++)
            {
                sBox[i] = -1;
            }
            string sBoxString = "SBox #" + pordyadkoviyNomerNaRukave + "\r ";
            for (int i = 0; i < sBox.Length; i++)
            {
                bool quit = false;
                while (!quit)
                {
                    int val = i;
                    int rand = rnd.Next(0, 256);
                    int res = val ^ rand;
                    //int cbI = CountBits(i);
                    //int cbR = CountBits(res);
                    bool fail = false;
                    straightFails++;
                    if (straightFails > 30000)
                    {
                        return new int[0];

                        straightFails = 0;
                    }
                    if (CountBits(res) > lim)
                    {
                        //check if already exist
                        for (int q = 0; q < sBox.Length; q++)
                        {
                            if (sBox[q] == rand)
                            {
                                fail = true;
                                break;
                            }
                        }
                        if (!fail)
                        {
                            sBox[i] = rand;
                            quit = true;
                            straightFails = 0;
                            sBoxString += i + ";" + rand + " \r ";


                        }
                        else
                        if (i == 255 && fail && sBox[255] == 0 && rand == 0)
                        {
                            //sBox[i] = rand;
                            //quit = true;
                            //straightFails = 0;
                            //sBoxString += i + ";" + rand + " \r ";
                            return new int[0];
                        }

                    }
                }

            }
            bool shitHappend;
            for (int i = 0; i < sBox.Length; i++)
            {
                for (int q = i + 1; q < sBox.Length; q++)
                    if (sBox[i] == sBox[q])
                        shitHappend = true;
            }
            sw.WriteLine(sBoxString);
            sw.Flush();

            return sBox;
        }

        static int CountBits(int n) // copied
        {
            int test = n;
            int count = 0;

            while (test != 0)
            {
                if ((test & 1) == 1)
                {
                    count++;
                }
                test >>= 1;
            }
            return count;
        }



        public int[] createPBox() // copied
        {

            bool failed = false;
            int[] pBox = new int[KlvSBOXES * 8];
            for (int i = 0; i < KlvSBOXES * 8; i++)
            {
                pBox[i] = -1;
            }
            for (int i = 0; i < KlvSBOXES * 8; i++)
            {
                failed = false;
                int val = rnd2.Next(0, KlvSBOXES * 8);

                for (int q = 0; q < KlvSBOXES * 8; q++)
                {
                    if (pBox[q] == val)
                    {
                        failed = true;
                    }
                }
                if (failed)
                {
                    i--;
                    continue;
                }
                pBox[i] = val;

            }
            return pBox;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            createPBox();
        }
        public int[][] createDecodeSBox(int[][] sBoxes) // copied
        {
            int[][] revSBoxes = new int[nmbOfRound * KlvSBOXES][];
            for (int i = 0; i < revSBoxes.Length; i++)
            {
                var curBox = new int[256];
                for (int q = 0; q < curBox.Length; q++)
                {
                    curBox[q] = -1;
                }
                revSBoxes[i] = curBox;
            }
            for (int i = 0; i < nmbOfRound * KlvSBOXES; i++)
            {
                int[] curSBox = sBoxes[i];
                int[] curRevSBox = revSBoxes[i];
                for (int q = 0; q < curSBox.Length; q++)
                {
                    int val = curSBox[q];
                    curRevSBox[val] = q;
                }
                revSBoxes[i] = curRevSBox;
            }
            return revSBoxes;
        }

        public static string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        public string createZeros(int numberOfZeros)
        {
            if (numberOfZeros <= 0) { return ""; }
            string str = "";
            for (int i = 0; i < numberOfZeros; i++)
            {
                str += "0";
            }
            return str;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            roundCounter++;
            if (roundCounter >= nmbOfRound) return;
            Bitmap img = new Bitmap(pictureBox1.Image);
            Bitmap newImg = new Bitmap(img);
            int[] sBoxForThisRound;
            int[] PBoxForThisRound;
            string str = "";
            Color px;
            bool failed = false;
            for (int i = 0; i < img.Height; i++)
            {
                PBoxForThisRound = pBoxes[roundCounter];
                failed = false;
                string res = "";
                for (int q = 0; q < img.Width; q = q + 3)
                {
                    int aftSBox = 0;
                    res = "";
                    for (int w = 0; w < KlvSBOXES; w++) // 3 пикселя за раз
                    {
                        sBoxForThisRound = sBoxes[(roundCounter * KlvSBOXES) + w];
                        if (q + w >= img.Width)
                        {
                            failed = true;
                            continue;
                        }
                        px = img.GetPixel(q + w, i);
                        byte grayScael = px.G;
                        int grScAsInt = Convert.ToInt32(grayScael);

                       int curVal = sBoxForThisRound[grScAsInt];
                       string temp = Convert.ToString(curVal, 2);
                        temp = createZeros(8 - temp.Length) + temp;
                        res = temp + res;

                        byte alpha = px.A; // для интереса

                    } // до этой части проверено
                    
                    if (failed) continue;
                    int resAsInt = Convert.ToInt32(res, 2);
                    int afterPencoding = encodePBox(PBoxForThisRound, resAsInt);
                    string asString = Convert.ToString(afterPencoding, 2);
                    asString = createZeros(KlvSBOXES * 8 - asString.Length) + asString;
                    asString = Reverse(asString);
                    int setter = 0;
                   // добавляем, чтобы длина было целым числом байт
                    for (int v = 0; v < asString.Length; v = v + 8)
                    { // задаём каждому байту своё значение после pBox`а
                        string part = asString.Substring(v, 8);
                        part = Reverse(part);
                        int prtAsInt = Convert.ToInt32(part, 2); // правильно получаю нужную часть
                        byte newgrayScale = Convert.ToByte(prtAsInt);
                        Color newPixel = Color.FromArgb(255, newgrayScale, newgrayScale, newgrayScale);

                        newImg.SetPixel(q + setter, i, newPixel);
                        setter++;
                    }
                  
                }
            }
            pictureBox1.Image = newImg;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Bitmap img = (Bitmap) pictureBox1.Image;
            Bitmap newImg = new Bitmap(img);
            int[] sInvBoxForThisRound;
            int[] PInvBoxForThisRound;
            string str = "";
            Color px;
            bool failed = false;

            if (roundCounter <= -1) return;
            for (int i = 0; i < img.Height; i++)
            {

                PInvBoxForThisRound = revPBoxes[roundCounter];
                failed = false;
                for (int q = 0; q < img.Width; q = q + 3)
                {
                    string res = "";
                    for (int w = 0; w < KlvSBOXES; w++) // 3 пикселя за раз
                    {
                        if(q + w >= img.Width){
                            failed = true;
                            continue; }
                        px = img.GetPixel(q + w, i);
                        byte grayScael = px.G;
                        int grScAsInt = Convert.ToInt32(grayScael);
                        string tmp = Convert.ToString(grScAsInt, 2);
                        tmp = createZeros(8 - tmp.Length) + tmp  ;
                        res = tmp + res; // check this one - должно быть первые 3 пикселя в ряд
                    }
                    if (failed) continue;
                    int clctValsInt = Convert.ToInt32(res, 2);
                    int afterInvPBox = decodePBox(PInvBoxForThisRound, clctValsInt);
                    string tmp2 = Convert.ToString(afterInvPBox, 2);
                    string afterInvBoxStr = createZeros(KlvSBOXES * 8 - tmp2.Length) + tmp2;
                    string afterInvBoxStrInvert = Reverse(afterInvBoxStr);
                    for (int k = 0; k < KlvSBOXES; k++) {
                        int[] invSBox = revSBoxes[(roundCounter * KlvSBOXES) + k];
                        string prt = afterInvBoxStrInvert.Substring(k * 8,8);
                        prt = Reverse(prt);
                        int prtInt = Convert.ToInt32(prt, 2); // верно, нужную часть получил
                        int rs =  invSBox[prtInt];
                        byte newgrayScale = Convert.ToByte(rs);
                        Color newPixel = Color.FromArgb(255, newgrayScale, newgrayScale, newgrayScale);

                        newImg.SetPixel(q + k, i, newPixel);
                        
                    }
                }
            }
            pictureBox1.Image = newImg;
            roundCounter--;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 chart = new Form2();
            chart.setImage((Bitmap) pictureBox1.Image);
            chart.Show();
         //   chart1.Series[0].Points.Clear();
        //    Bitmap graph = new Bitmap(500,500);
            //Bitmap image = new Bitmap(pictureBox1.Image);
            //for (int i = 0; i < image.Height; i++) {
            //    for (int k = 1; k < image.Width; k++) {
            //        byte grScale1 = image.GetPixel(k, i).G;
            //        byte grScale0 = image.GetPixel(k -1, i).G;
            //        chart1.Series["Dots"].Points.AddXY(grScale0, grScale1);
            //    }

            //}

        }

        private void button5_Click(object sender, EventArgs e)
        {
          Image img =   pictureBox1.Image;
            string filepath = "D:\\laba\\encodedImg.jpg";
            img.Save(filepath, ImageFormat.Jpeg);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            roundCounter = nmbOfRound - 1;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

